<!DOCTYPE html>
<html lang="en">
<head>
	<title>About Betsek Investment    </title>
	<?php include "include/meta.php";?>

</head>
<body>
<?php include "include/nav.php";?>

	<!-- Page info section -->
	<section class="page-info-section">
		<div class="container">
			<h2>About Us</h2>
			<div class="site-beradcamb">
				<a href="">Home</a>
				<span><i class="fa fa-angle-right"></i> About Us</span>
			</div>
		</div>
	</section>
	<!-- Page info end -->


	<!-- About section -->
	<section class="about-section spad">
		<div class="container">
			<div class="row">
				<div class="col-lg-6 offset-lg-6 about-text">
					<h2>We are Betsek </h2>
					<h5>Betsek is an innovative crypto inventment  network  that makes investing easy and secured..</h5>
					<p> Invest in assets and connect with people on the world's social investing platform</p>
					<a href="/register" class="site-btn sb-gradients sbg-line mt-5">Get Started</a>
				</div>
			</div>
			<div class="about-img">
				<img src="img/about-img.png" alt="">
			</div>
		</div>
	</section>
	<!-- About section end -->


	<!-- Fact section -->
	<section class="fact-section gradient-bg">
		<div class="container">
			<div class="row">
				<div class="col-sm-6 col-md-6 col-lg-3">
					<div class="fact">
						<h2>60</h2>
						<p>Support <br> Countries</p>
						<i class="ti-basketball"></i>
					</div>
				</div>
				<div class="col-sm-6 col-md-6 col-lg-3">
					<div class="fact">
						<h2>12K</h2>
						<p>Transactions  <br> per hour</p>
						<i class="ti-panel"></i>
					</div>
				</div>
				<div class="col-sm-6 col-md-6 col-lg-3">
					<div class="fact">
						<h2>5B</h2>
						<p>Largest <br> Transactions</p>
						<i class="ti-stats-up"></i>
					</div>
				</div>
				<div class="col-sm-6 col-md-6 col-lg-3">
					<div class="fact">
						<h2>24</h2>
						<p>Years <br> of Experience</p>
						<i class="ti-user"></i>
					</div>
				</div>
			</div>
		</div>
	</section>
	<!-- Fact section end -->


	<!-- Review section -->
	<section class="review-section spad">
		<div class="container">
			<div class="row">
				<div class="col-lg-8 push-8">
					<img src="img/quote.png" alt="" class="quote mb-5">
					<div class="review-text-slider owl-carousel">
						<div class="review-text">
							<p>"  I was able to work with my finances thanks to Betsek  and discovered a fantastic way to make money all day long without having to go to work! I developed an interest in investing and the economics, so I can make some predictions about bitcoin..”</p>
						</div>
						<div class="review-text">
							<p>" I've been using Betsek  since last year. I always keep up with new developments so I don't miss anything. Bitcoin is a fantastic and truly innovative way to make money! I mine continuously and pay my bills on time.”</p>
						</div>
						<div class="review-text">
							<p>" I bought a Basic Plan investment. It was difficult to wait days for my bitcoins to double, but the most crucial factor is that this service is legitimate and pays. Plus for helpful and understanding support. I'll invest one more.”</p>
						</div>
					</div>
				</div>
				<div class="col-lg-4 pr-0 pull-3">
					<div class="review-meta-slider owl-carousel pt-5">
						<div class="author-meta">
							<div class="author-avatar set-bg" data-setbg="img/review/1.jpg"></div>
							<div class="author-name">
								<h4>Aaron Ballance</h4>
 							</div>
						</div>
						<div class="author-meta">
							<div class="author-avatar set-bg" data-setbg="img/review/2.jpg"></div>
							<div class="author-name">
								<h4>Jackson Nash</h4>
 							</div>
						</div>
						<div class="author-meta">
							<div class="author-avatar set-bg" data-setbg="img/review/3.jpg"></div>
							<div class="author-name">
								<h4>Katy Abrams</h4>
 							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</section>
	<!-- Review section end -->


	<!-- Newsletter section -->
	<section class="newsletter-section gradient-bg">
		<div class="container text-white">
			<div class="row">
				<div class="col-lg-7 newsletter-text">
					<h2>Subscribe to our Newsletter</h2>
					<p>Sign up for our weekly industry updates, insider perspectives and in-depth market analysis.</p>
				</div>
				<div class="col-lg-5 col-md-8 offset-lg-0 offset-md-2">
					<form action ='/register' class="newsletter-form">
						<input type="text" placeholder="Enter your email">
 	<button>Get Started</button>
					</form>
				</div>
			</div>
		</div>
	</section>
	<!-- Newsletter section end -->


    <?php include "include/footer.php";?>
</body>
</html>
