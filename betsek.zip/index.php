<!DOCTYPE html>
<html lang="en">
<head>
	<title>Betsek Investment Platform </title>
<?php include "include/meta.php";?>
</head>
<body>


<?php include "include/nav.php";?>

	<!-- Hero section -->
	<section class="hero-section">
		<div class="container">
			<div class="row">
				<div class="col-md-6 hero-text">
					<h2>Invest in <span>Bitcoin</span> <br>Bitcoin Trading</h2>
					<h4>Use modern progressive technologies of Bitcoin to earn money</h4>
					<form action ='/register' class="hero-subscribe-from">
						<input type="text" placeholder="Enter your email">
  <button class="site-btn sb-gradients">   Get Started </button>
					</form>
				</div>
				<div class="col-md-6">
					<img src="img/laptop.png" class="laptop-image" alt="">
				</div>
			</div>
		</div>
	</section>
	<!-- Hero section end -->


	<!-- About section -->
	<section class="about-section spad">
		<div class="container">
			<div class="row">
				<div class="col-lg-6 offset-lg-6 about-text">
					<h2 > We  are Betsek</h2>
					<h5>Betsek is the easiest place to invest.</h5>
					<p>Betsek provides technology and Product that make trust less expensive and complex.</p>
					<a href="/register" class="site-btn sb-gradients sbg-line mt-5">Get Started</a>
				</div>
			</div>
			<div class="about-img">
				<img src="img/about-img.png" alt="">
			</div>
		</div>
	</section>
	<!-- About section end -->


	<!-- Features section -->
	<section class="features-section spad gradient-bg">
		<div class="container text-white">
			<div class="section-title text-center">
				<h2>Our Features</h2>
				<p>Betsek is the simplest way to invest money at very low cost.</p>
			</div>
			<div class="row">
				<!-- feature -->
				<div class="col-md-6 col-lg-4 feature">
					<i class="ti-mobile"></i>
					<div class="feature-content">
						<h4>  Worldwide Access</h4>
						<p>Invest with us no matter where you are located. No restrictions even for users from China or USA. </p>
						
					</div>
				</div>
				<!-- feature -->
				<div class="col-md-6 col-lg-4 feature">
					<i class="ti-shield"></i>
					<div class="feature-content">
						<h4>Safe & Secure</h4>
						<p>We secure all user data by using 256-bit EV SSL security certificate. </p>
 					</div>
				</div>
				<!-- feature -->
				<div class="col-md-6 col-lg-4 feature">
					<i class="ti-wallet"></i>
					<div class="feature-content">
						<h4>Wallet</h4>
						<p> Your bitcoins are sent to your address as soon as you submit your request. </p>
 					</div>
				</div>
				<!-- feature -->
				<div class="col-md-6 col-lg-4 feature">
					<i class="ti-headphone-alt"></i>
					<div class="feature-content">
						<h4>Experts Support</h4>
						<p>Our support will answer your questions in shortest time possible. </p>
 					</div>
				</div>
				<!-- feature -->
				<div class="col-md-6 col-lg-4 feature">
					<i class="ti-reload"></i>
					<div class="feature-content">
						<h4>Instant Exchange</h4>
						<p> We tend to be the cryptocurrency investments with highest ROI </p>
 					</div>
				</div>
				<!-- feature -->
				<div class="col-md-6 col-lg-4 feature">
					<i class="ti-panel"></i>
					<div class="feature-content">
						<h4>Recuring Buys</h4>
						<p>We tend to give preference to recuring investors </p>
 					</div>
				</div>
			</div>
		</div>
	</section>
	<!-- Features section end -->

<?php include "include/hiw.php"?>

	<!-- Fact section -->
	<section class="fact-section gradient-bg">
		<div class="container">
			<div class="row">
				<div class="col-sm-6 col-md-6 col-lg-3">
					<div class="fact">
						<h2>60</h2>
						<p>Support <br> Countries</p>
						<i class="ti-basketball"></i>
					</div>
				</div>
				<div class="col-sm-6 col-md-6 col-lg-3">
					<div class="fact">
						<h2>12K</h2>
						<p>Transactions  <br> per hour</p>
						<i class="ti-panel"></i>
					</div>
				</div>
				<div class="col-sm-6 col-md-6 col-lg-3">
					<div class="fact">
						<h2>5B</h2>
						<p>Largest <br> Transactions</p>
						<i class="ti-stats-up"></i>
					</div>
				</div>
				<div class="col-sm-6 col-md-6 col-lg-3">
					<div class="fact">
						<h2>240</h2>
						<p>Years <br> of Experience</p>
						<i class="ti-user"></i>
					</div>
				</div>
			</div>
		</div>
	</section>
	<!-- Fact section end -->
 

	<!-- Review section -->
	<section class="review-section spad">
		<div class="container">
			<div class="row">
				<div class="col-lg-8 push-8">
					<img src="img/quote.png" alt="" class="quote mb-5">
					<div class="review-text-slider owl-carousel">
						<div class="review-text">
							<p>"  I was able to work with my finances thanks to Betsek  and discovered a fantastic way to make money all day long without having to go to work! I developed an interest in investing and the economics, so I can make some predictions about bitcoin..”</p>
						</div>
						<div class="review-text">
							<p>" I've been using Betsek  since last year. I always keep up with new developments so I don't miss anything. Bitcoin is a fantastic and truly innovative way to make money! I mine continuously and pay my bills on time.”</p>
						</div>
						<div class="review-text">
							<p>" I bought a Basic Plan investment. It was difficult to wait days for my bitcoins to double, but the most crucial factor is that this service is legitimate and pays. Plus for helpful and understanding support. I'll invest one more.”</p>
						</div>
					</div>
				</div>
				<div class="col-lg-4 pr-0 pull-3">
					<div class="review-meta-slider owl-carousel pt-5">
						<div class="author-meta">
							<div class="author-avatar set-bg" data-setbg="img/review/1.jpg"></div>
							<div class="author-name">
								<h4>Aaron Ballance</h4>
 							</div>
						</div>
						<div class="author-meta">
							<div class="author-avatar set-bg" data-setbg="img/review/2.jpg"></div>
							<div class="author-name">
								<h4>Jackson Nash</h4>
 							</div>
						</div>
						<div class="author-meta">
							<div class="author-avatar set-bg" data-setbg="img/review/3.jpg"></div>
							<div class="author-name">
								<h4>Katy Abrams</h4>
 							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</section>
	<!-- Review section end -->


	<!-- Newsletter section -->
	<section class="newsletter-section gradient-bg">
		<div class="container text-white">
			<div class="row">
				<div class="col-lg-7 newsletter-text">
					<h2>Subscribe to our Newsletter</h2>
					<p>Sign up for our weekly industry updates, insider perspectives and in-depth market analysis.</p>
				</div>
				<div class="col-lg-5 col-md-8 offset-lg-0 offset-md-2">
					<form action ='/register' class="newsletter-form">
						<input type="text" placeholder="Enter your email">
						<button>Get Started</button>
					</form>
				</div>
			</div>
		</div>
	</section>
	<!-- Newsletter section end -->

<?php include "include/packages.php" ; ?>
	<!-- Footer section -->
	
<?php include "include/footer.php" ; ?>
</body>
</html>
