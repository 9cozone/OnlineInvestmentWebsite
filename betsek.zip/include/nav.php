	<!-- Page Preloder -->
	<div id="preloder">
		<div class="loader"></div>
	</div>

	<!-- Header section -->
	<header class="header-section clearfix">
		<div class="container-fluid">
			<a href="index.php" class="site-logo">
				<img src="img/logo.png" alt="">
			</a>
			<div class="responsive-bar"><i class="fa fa-bars"></i></div>
			<a href="" class="user"><i class="fa fa-user"></i></a>
			<a href="/register" class="site-btn">Sign Up  </a>
			<a href="/login" class="site-btn">Login </a>
			<nav class="main-menu">
				<ul class="menu-list">
  					<li><a href="about.php">About us</a></li>
  					<li><a href="packages.php">Packages  </a></li>
					<li><a href="contact.php">Contact</a></li>
				</ul>
			</nav>
		</div>
	</header>
	<!-- Header section end -->