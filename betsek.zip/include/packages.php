

	<!-- Blog section -->
	<section class="blog-section spad">
		<div class="container">
			<div class="section-title text-center">
				<h2>BETSEK PACKAGES </h2>
				<p>Bitcoin is the simplest way to exchange money at very low cost.</p>
			</div>
			<div class="row">
				<!-- blog item -->
				<div class="col-md-4">
					<div class="blog-item">
						<figure class="blog-thumb">
							<img src="img/blog/1.jpg" alt="">
						</figure>
						<div class="blog-text">
							<div class="post-date">  Basic</div>
							<h4 class="blog-title"><a href=""> Starts From
$10.00
To
maximum
$200.00
</a></h4>
<p>5.00% Referal Bonus, 3% daily ROI
 You can withdrawals funds once in 7 days
Other Special Benefits
*Capitals are Withdrawable</p>
							 
                            <a href="../register" class="site-btn sb-gradients sbg-line mt-5">Get Started</a>

						</div>
                        

					</div>
                    
				</div>
				<!-- blog item -->
				<div class="col-md-4">
					<div class="blog-item">
						<figure class="blog-thumb">
							<img src="img/blog/2.jpg" alt="">
						</figure>
						<div class="blog-text">
							<div class="post-date">Gold</div>
							<h4 class="blog-title"><a href="">
								
							Starts From
$300.00
To
maximum
$3000.00
</a></h4>
<p>5.00% Referal Bonus, 5% daily ROI
 You can withdrawals funds once in 7 days
Other Special Benefits
*Capitals are Withdrawable</p>						 
                            <a href="../register" class="site-btn sb-gradients sbg-line mt-5">Get Started</a>

						</div>
					</div>
				</div>
				<!-- blog item -->
				<div class="col-md-4">
					<div class="blog-item">
						<figure class="blog-thumb">
							<img src="img/blog/3.jpg" alt="">
						</figure>
						<div class="blog-text">
							<div class="post-date">Silver    </div>
							<h4 class="blog-title"><a href="">
								
							Starts From
$3000.00
To
maximum
$50000.00
</a></h4>
<p>5.00% Referal Bonus, 6% daily ROI
 You can withdrawals funds once in 7 days
Other Special Benefits
*Capitals are Withdrawable</p>						 
                            <a href="../register" class="site-btn sb-gradients sbg-line mt-5">Get Started</a>

						</div>
					</div>
				</div>
			</div>
		</div>
	</section>
	<!-- Blog section end -->